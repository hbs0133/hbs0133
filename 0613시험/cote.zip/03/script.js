let text = document.querySelector("input")
let save = document.querySelector(".btnSave")
let remove = document.querySelector(".btnRemove")
let clear = document.querySelector(".btnRemove")


save.addEventListener("click", function(){
  let textValue = text.value
  window.localStorage.setItem(`text`,`${textValue}`)
  text.value = ""
})

remove.addEventListener("click", function(){
  window.localStorage.removeItem(`text`);
})

clear.addEventListener("click",function(){
  window.localStorage.clear();
})