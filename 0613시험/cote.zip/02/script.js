let text = document.querySelector("input")
let save = document.querySelector(".btnSave")
let read = document.querySelector(".btnRead")

save.addEventListener("click", function(){
  let textValue = text.value
  window.localStorage.setItem(`text`,`${textValue}`)
  text.value = ""
})

read.addEventListener("click", function(){
  let textValue = window.localStorage.getItem(`text`)
  text.value = textValue
})