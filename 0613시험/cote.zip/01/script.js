setInterval(()=>{
  let current = new Date();
  
  const Hrs = document.querySelector(".lineHour");
  const Min = document.querySelector(".lineMin");
  const Sec = document.querySelector(".lineSec");

  let H = current.getHours();
  let M = current.getMinutes();
  let S = current.getSeconds();
  
  let degH = H * 30 + M * 0.5;
  let degM =  M * 6;
  let degS = S * 6;
  
  Hrs.style.transform = `rotate(${degH}deg)`;
  Min.style.transform = `rotate(${degM}deg)`;
  Sec.style.transform = `rotate(${degS}deg)`;
},1000)