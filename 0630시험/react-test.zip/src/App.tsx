import React , {useState} from 'react';
import logo from './logo.svg';
import './App.css'
import { styled } from 'styled-components'
import Header from './Component/Header';
import Body from './Component/Body'
import Footer from './Component/Footer';

const Container = styled.div`
  width : 400px;
  height: 800px;
  border: 1px solid lightblue;
  box-shadow: 5px 5px 10px lightblue;
  display: flex;
  flex-direction: column;
  padding : 50px;
  gap : 50px
`
const [email, setEmail] = useState("")

const handleOnChangeEmail = (e:any) => {
  setEmail(e.target.value)
}

// const handleOnChangeName = (e:any) => {
//   setName(e.target.value)
// }
// const handleOnChangePw = (e:any) => {
//   setPw(e.target.value)
// }
// const handleOnChangeConfirm = (e:any) => {
//   setPwConfirm(e.target.value)
// }


// const [name, setName] = useState("")
// const [pw, setPw] = useState("")
// const [pwConfirm, setPwConfirm] = useState("")


function App() {
  return (
    <div className='App'>
      <Container>
        <Header />
        <Body />
        <Footer />
      </Container>
    </div>
  );
}

export default App;
