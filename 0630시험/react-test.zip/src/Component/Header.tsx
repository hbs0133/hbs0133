import React from 'react'
import { styled } from 'styled-components'


const Title = styled.div`
  color : #0a82f1;
  font-size : 28px;
  font-weight : bold;
  margin-top : 20px;
`

const Header = () => {
  return (
    <div>
      <Title>회원가입을 위해 <br /> 정보를 입력해주세요</Title>
    </div>
  )
}

export default Header
