import React from 'react'
import { styled } from 'styled-components'

const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
`
const Button = styled.button`
  border: 1px solid #0a82f1;
  background-color: transparent;
  color : #0a82f1;
  padding : 20px 150px;
  border-radius: 10px;
  font-size : 16px;
`

const Footer = () => {
  return (
    <Container>
      <Button>가입하기</Button>
    </Container>
  )
}

export default Footer
