import React, { useState } from 'react'
import { styled } from 'styled-components'



const Container = styled.div`
  display : flex;
  flex-direction: column;
  gap : 50px;
  padding-bottom: 40px;
  border-bottom : 1px solid #ccc;
`

const InputSpace = styled.div`
  display : flex;
  flex-direction: column;
  gap : 15px;
  color : #888;
`
const Label = styled.div`


`
const Input = styled.input`
  outline: none;
  border : none;
  border-bottom: 1px solid #ccc;
  width : 400px;
  &:hover {
    border-bottom: 1px solid #0a82f1;
  }
  &:focus {
    border-bottom: 1px solid #0a82f1;
  }
`

const InputCheckSpace = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap : 10px;
`

const InputCheck = styled.input`

`

const AgreeSpace = styled.div`
  display: flex;
  gap : 5px;
  padding
`

const Span = styled.div`
  font-size : 12px;
`

const [email, setEmail] = useState("")

const handleOnChangeEmail = (e:any) => {
  setEmail(e.target.value)
}

const handleOnChangeName = (e:any) => {
  setName(e.target.value)
}
const handleOnChangePw = (e:any) => {
  setPw(e.target.value)
}
const handleOnChangeConfirm = (e:any) => {
  setPwConfirm(e.target.value)
}


const [name, setName] = useState("")
const [pw, setPw] = useState("")
const [pwConfirm, setPwConfirm] = useState("")



const Body = () => {
  return (
    <Container>
      <InputSpace>
        <Label>* {email}</Label>
        <Input onChange={handleOnChangeEmail} type="text" />
      </InputSpace>
      <InputSpace>
        <Label>* {name}</Label>
        <Input onChange={handleOnChangeName} type="text" />
      </InputSpace>
      <InputSpace>
        <Label>* {pw}</Label>
        <Input onChange={handleOnChangePw} type="text" />
      </InputSpace>
      <InputSpace>
        <Label>* {pwConfirm}</Label>
        <Input onChange={handleOnChangeConfirm} type="text" />
      </InputSpace>
      <InputCheckSpace>
        <InputCheck type="radio" />
          <label>여성</label>
        <InputCheck type="radio" />
          <label>남성</label>
      </InputCheckSpace>
      <AgreeSpace>
      <input type="checkbox" />
      <Span>이용약관 개인정보 수정 및 이용 마케팅 활용 선택에 모두 동의합니다</Span>
      </AgreeSpace>
    </Container>
  )
}

export default Body
