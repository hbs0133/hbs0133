const error = function() {
  let email = document.querySelector("#email").value
  let name =  document.querySelector("#name")
  let pw = document.querySelector("#pw").value
  let pwConfirm = document.querySelector("#pwConfirm").value

  // email == "" ? document.querySelector(".emailError").style.display = "block"
}

const quoteBtn = document.querySelector("#quoteBtn")
const quoteNum = document.querySelector(".quoteNum")

const phoneNum = document.querySelectorAll(".phoneNum input").value


quoteBtn.addEventListener("click", () => {
  const Num = String(Math.floor(Math.random()*1000000)).padStart(6, "0");
  quoteNum.innerText = Num
})


if(phoneNum != ""){
  quoteBtn.disabled = false
}else{
  quoteBtn.disabled = true
}