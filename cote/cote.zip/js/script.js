// $('.my-img').slick({
//   infinite: true,
//   slidesToShow: 1,
//   slidesToScroll: 1
// });
$('.my-img').slick({
  slidesToShow: 2,
  slidesToScroll: 2,
  autoplay: true,
  autoplaySpeed: 800,
});